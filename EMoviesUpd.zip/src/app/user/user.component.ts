import { Component, OnInit } from '@angular/core';
import { User } from './user.model';
import { FormsModule,NgForm } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-user',
  standalone: true,
  imports: [FormsModule,CommonModule],
  templateUrl: './user.component.html',
  styleUrl: './user.component.css'
})
export class UserComponent {
// ngOnInit(): void {
//  console.log()
// }
user = new User();

save(userform:NgForm)
{
  console.log(userform.dirty);
  console.log(userform.form);
  console.log(userform.valid);
  
  console.log("Saved info " + JSON.stringify(userform.value))
}
}
