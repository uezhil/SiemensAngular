export class User{
    constructor(
        public firstName='',
        public city='',
        public email=''
    )
    {}
}