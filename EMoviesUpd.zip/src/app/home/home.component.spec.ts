import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeComponent } from './home.component';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';

describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HomeComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should render Hello! EMovies', () => {
    const fixture = TestBed.createComponent(HomeComponent);
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('h1')?.textContent).toContain('Hello,EMovies');
  });

  it('should have a h5 tag of `At home`',()=>{
    let de: DebugElement = fixture.debugElement;
    expect(de.query(By.css('h5')).nativeElement.innerText).toBe('At home');
  })

  it('should have elements with this class - chk',()=>{
    const chk1 = fixture.debugElement.query(By.css('.chk')).nativeElement;
    expect(chk1.innerHTML).not.toBeNull();
    expect(chk1.innerHTML.length).toBeGreaterThan(0);

  })


});
