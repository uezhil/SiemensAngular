import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, map, Observable, tap, throwError } from 'rxjs';
import { IMovie } from './movies.model';

@Injectable({
  providedIn: 'root'
})
export class MovieServiceObs {

  private movieurl = 'api/movies/movies.json';

  //Dep Inj
  constructor(private http:HttpClient) { }

  getMovies():Observable<IMovie[]>{
    return this.http.get<IMovie[]>(this.movieurl).pipe(
        tap(data =>console.log('All', JSON.stringify(data))),
        catchError(this.handleError)

    );
    }

    getMovieById(id:number):Observable<IMovie|undefined>{
      return this.getMovies()
      .pipe(
        map((movies:IMovie[])=>movies.find(m=>m.movieID === id)),
        catchError(this.handleError)
      )

    }

  private handleError(err:HttpErrorResponse){
    let errorMessage = '';

    if(err.error instanceof ErrorEvent){
        errorMessage = `An error occured : ${err.error.message}`;

    }
    else{
        errorMessage = `Server code: ${err.status} ,error message: ${err.message}`;

    }
    console.log(errorMessage);
    return throwError(()=>errorMessage);
}

}
