import { HttpInterceptorFn } from '@angular/common/http';

export const authtokenInterceptor: HttpInterceptorFn = (req, next) => {
  const authtoken = localStorage.getItem('angularToken');
  const reqcopy = req.clone({
    setHeaders:{
      Authorization:`Bearer ${authtoken}`
    }
  })

  return next(reqcopy);
};
