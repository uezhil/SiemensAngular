import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {  ActivatedRoute, Router, RouterModule} from "@angular/router";
import { MovieService } from '../movies/movies.service';
import { IMovie } from '../movies/movies.model';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faCircleInfo } from '@fortawesome/free-solid-svg-icons';
import { faCirclePlay } from '@fortawesome/free-solid-svg-icons';
import { MovieServiceObs } from '../movies/movie-service-obs.service';



@Component({
  selector: 'app-movie-detail',
  standalone: true,
  imports: [RouterModule,CommonModule,FormsModule,FontAwesomeModule],
  templateUrl: './movie-detail.component.html',
  styleUrl: './movie-detail.component.css'
})
export class MovieDetailComponent implements OnInit {
  faCircleInfo = faCircleInfo;
  faCirclePlay = faCirclePlay

id:number|undefined;
movie:IMovie |undefined;
errorMessage:string|undefined;

//Dependency Injection  
  constructor(
    private router:Router,private route:ActivatedRoute,
    private movService:MovieServiceObs){
    
  }
  ngOnInit(): void {
   //this.id = this.route.snapshot.params['id'];

   this.route.paramMap.subscribe((map) =>
    {
    this.id = +map.get('id')!;
    if(this.id)
  { this.movService.getMovieById(this.id).subscribe({
    next:movie => this.movie = movie,
    error:err => this.errorMessage = err
   });
  }
});
}


  onBack(){
    this.router.navigate(['/movies']);
  }
  onEdit(){
    this.router.navigate(['/movies',this.id,'edit'])//https://localhost:4200/movies/3/edit
  }

}
