import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { IMovie } from './movies.model';


@Component({
  selector: 'app-movies',
  standalone: true,
  imports: [CommonModule, RouterOutlet],
  templateUrl: './movies.component.html',
  styleUrl: './movies.component.css'
})

export class MoviesComponent {
  imgWidth = 200;
imgHeight = 150;
dispPic:boolean = true;

  movies:IMovie[] = [ {
    "movieID":1,
    "movieName":"Avengers - EndGame",
    "movieStar":"Robert Downey",
    "movieGenre":"Action",
    "movieRating":5.0,
    "movieImg":"assets/images/avenger1.png"
},
{
"movieID":2,
"movieName":"Antman",
"movieStar":"Paul Rudd",
"movieGenre":"Action",
"movieRating":4,
"movieImg":"assets/images/antman.jpg"
},
{
"movieID":3,
"movieName":"How to train - your Dragon",
"movieStar":"Hiccup - Thames",
"movieGenre":"Animated",
"movieRating":3,
"movieImg":"assets/images/how-to-train-your-dragon-3.jpg"

},
{
"movieID":4,
"movieName":"Tangled",
"movieStar":"Mandy-moore",
"movieGenre":"SciFi",
"movieRating":4.5,
"movieImg":"assets/images/tangled.jpg"

},
{
"movieID":5,
"movieName":"Moana",
"movieStar":"Dawyne",
"movieGenre":"Animated",
"movieRating":5,
"movieImg":"assets/images/moana.jpg"

},
{
"movieID":6,
"movieName":"I-T",
"movieStar":"Pennywise",
"movieGenre":"Horror",
"movieRating":3.8,
"movieImg":"assets/images/it.jpg"

},
{
"movieID":7,
"movieName":"Matrix",
"movieStar":"Keanu Reeves",
"movieGenre":"SciFi",
"movieRating":5,
"movieImg":"assets/images/matrix.jpg"

},
{
"movieID":8,
"movieName":"Avatar - The Way of Water",
"movieStar":"Sam Worthington",
"movieGenre":"SciFi",
"movieRating":4,
"movieImg":"assets/images/Avatar.jpg"

}
  ]

  togImgMode():void{
    this.dispPic = !this.dispPic;
  }
}
