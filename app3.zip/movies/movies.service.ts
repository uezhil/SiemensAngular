import { Injectable } from "@angular/core";
import { IMovie } from "./movies.model";

@Injectable({
    providedIn:'root'
})

export class MovieService{
private movies:IMovie[]=
[ {
    "movieID":1,
    "movieName":"Avengers - EndGame - From service",
    "movieStar":"Robert Downey",
    "movieGenre":"Action",
    "movieRating":5.0,
    "movieImg":"assets/images/avenger1.png"
},
{
"movieID":2,
"movieName":"Antman",
"movieStar":"Paul Rudd",
"movieGenre":"Action",
"movieRating":4,
"movieImg":"assets/images/antman.jpg"
},
{
"movieID":3,
"movieName":"How to train - your Dragon",
"movieStar":"Hiccup - Thames",
"movieGenre":"Animated",
"movieRating":3,
"movieImg":"assets/images/how-to-train-your-dragon-3.jpg"

},
{
"movieID":4,
"movieName":"Tangled",
"movieStar":"Mandy-moore",
"movieGenre":"SciFi",
"movieRating":4.5,
"movieImg":"assets/images/tangled.jpg"

},
{
"movieID":5,
"movieName":"Moana",
"movieStar":"Dawyne",
"movieGenre":"Animated",
"movieRating":5,
"movieImg":"assets/images/moana.jpg"

},
{
"movieID":6,
"movieName":"I-T",
"movieStar":"Pennywise",
"movieGenre":"Horror",
"movieRating":3.8,
"movieImg":"assets/images/it.jpg"

},
{
"movieID":7,
"movieName":"Matrix",
"movieStar":"Keanu Reeves",
"movieGenre":"SciFi",
"movieRating":5,
"movieImg":"assets/images/matrix.jpg"

},
{
"movieID":8,
"movieName":"Avatar - The Way of Water",
"movieStar":"Sam Worthington",
"movieGenre":"SciFi",
"movieRating":4,
"movieImg":"assets/images/Avatar.jpg"

}

]

getMovies(){
    return this.movies;
}

}