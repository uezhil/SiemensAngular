import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterOutlet } from '@angular/router';
import { IMovie } from './movies.model';
import { FormsModule } from "@angular/forms";
import { squareNum } from '../shared/myTransform.pipe';
import { MovieRatingComponent } from '../shared/movie-rating/movie-rating.component';
import { MovieService } from './movies.service';


@Component({
  selector: 'app-movies',
  standalone: true,
  imports: [CommonModule, RouterOutlet,FormsModule,squareNum,RouterLink,MovieRatingComponent],
  templateUrl: './movies.component.html',
  styleUrl: './movies.component.css'
})

export class MoviesComponent implements OnInit {
 
  imgWidth = 200;
imgHeight = 150;
imgRadius= 15;
title = "EMovies";
dispPic:boolean = true;

searchedMovies:IMovie[];
_searchTerm:string='';


get searchTerm():string{
  return this._searchTerm;
}

set searchTerm(value:string){
  this._searchTerm = value;
  this.searchedMovies = this.searchTerm?
  this.performSearch(this.searchTerm):this.movies;
}

//Dependency Injection
constructor (private _movService:MovieService){
  console.log("At the constructor phase..")
}

ngOnInit(): void {

  console.log("At the on init phase..");
  this.searchedMovies = this._movService.getMovies();
}



  movies:IMovie[] =[];
  

 

  togImgMode():void{
    this.dispPic = !this.dispPic;
  }

  performSearch(searchby:string):IMovie[]{
    searchby=searchby.toLocaleLowerCase();
    return this.movies.filter((movie:IMovie)=>
    movie.movieName.toLocaleLowerCase().indexOf(searchby)!==-1);
  }

  onRatingClicked(rate:string):void{
    this.title = 'Top Movies'+ rate;

  }
}
