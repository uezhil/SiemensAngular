import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {  ActivatedRoute, Router, RouterModule} from "@angular/router";
import { MovieService } from '../movies/movies.service';
import { IMovie } from '../movies/movies.model';

@Component({
  selector: 'app-movie-detail',
  standalone: true,
  imports: [RouterModule,CommonModule,FormsModule],
  templateUrl: './movie-detail.component.html',
  styleUrl: './movie-detail.component.css'
})
export class MovieDetailComponent implements OnInit {
id:number|undefined;
movie:IMovie |undefined;

//Dependency Injection
  constructor(
    private router:Router,private route:ActivatedRoute,
    private movService:MovieService){
    
  }
  ngOnInit(): void {
   //this.id = this.route.snapshot.params['id'];

   this.route.paramMap.subscribe((map) =>{
    this.id = +map.get('id')!;

   this.movie = this.movService.getMoviebyId(this.id)
   })
  }

  onBack(){
    this.router.navigate(['/movies']);
  }

}
