import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {  ActivatedRoute, Router, RouterModule} from "@angular/router";

@Component({
  selector: 'app-movie-detail',
  standalone: true,
  imports: [RouterModule,CommonModule,FormsModule],
  templateUrl: './movie-detail.component.html',
  styleUrl: './movie-detail.component.css'
})
export class MovieDetailComponent implements OnInit {
id:number|undefined;

  constructor(private router:Router,private route:ActivatedRoute){
    
  }
  ngOnInit(): void {
   this.id = this.route.snapshot.params['id'];
  }

  onBack(){
    this.router.navigate(['/movies']);
  }

}
