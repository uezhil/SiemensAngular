import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { MoviesComponent } from './movies/movies.component';
import { AboutComponent } from './about/about.component';
import { MovieDetailComponent } from './movie-detail/movie-detail.component';
import { UserComponent } from './user/user.component';
import { CustomerComponent } from './customer/customer.component';
import { MovieFormComponent } from './movie-form/movie-form.component';

//2.Configure the route table/route array with paths
//localhost:4200/
//localhost:4200/home
//localhost:4200/movies
//localhost:4200/aboutus
export const routes: Routes = [
{path:'home',component:HomeComponent},
{path:'movies',component:MoviesComponent},
{path:'movies/:id',component:MovieDetailComponent},
{path:'movies/:id/edit',component:MovieFormComponent},
{path:'about',component:AboutComponent},
{path:'user',component:UserComponent},
{path:'customer',component:CustomerComponent},
{path:'',component:HomeComponent},
{path:'**',component:HomeComponent,pathMatch:'full'}

  ]
  