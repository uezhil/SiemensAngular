import { Component } from '@angular/core';
import { IMovie } from '../movies/movies.model';
import { ActivatedRoute, Router } from '@angular/router';
import { MovieService } from '../movies/movies.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-movie-form',
  standalone: true,
  imports: [FormsModule,CommonModule],
  templateUrl: './movie-form.component.html',
  styleUrl: './movie-form.component.css'
})
export class MovieFormComponent {

  id:number|undefined;
movie:IMovie |undefined;

//Dependency Injection  
  constructor(
    private router:Router,private route:ActivatedRoute,
    private movService:MovieService){
    
  }
  ngOnInit(): void {
   this.route.paramMap.subscribe((map) =>{
    this.id = +map.get('id')!;

    
   this.movie = this.movService.getMoviebyId(this.id)
   })
  }

  onSave(){
    this.movService.updateMovie(this.movie);
    alert("Movie updated successfully");
    this.router.navigate(['/movies']);
  }


}
